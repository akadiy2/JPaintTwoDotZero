package command;

/**
 * Created by abhiramkadiyala on 2/11/18.
 */
public interface ICommand {

}
