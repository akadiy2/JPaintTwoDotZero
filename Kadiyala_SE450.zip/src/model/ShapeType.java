package model;

public enum ShapeType {
    RECTANGLE,
    ELLIPSE,
    TRIANGLE;
}
