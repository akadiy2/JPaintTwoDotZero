package model.shape;

import model.ShapeType;

import java.awt.*;

/**
 * Created by abhiramkadiyala on 2/7/18.
 */
public class Triangle extends Shape {


    public Triangle(Point p1, Point p2) {
        super(p1, p2);
    }

    @Override
    void setUp(Point p1, Point p2) {

    }

    @Override
    public void draw(Graphics2D graphics2D) {

    }
}
